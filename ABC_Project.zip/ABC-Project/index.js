// const header = document.querySelector('.header-nav');

// window.onscroll = function(){
//     var top = window.scrollY;

//     if (top >= 150){
//         header.classList.add('active')
//     }else{
//         header.classList.remove('active');
//     }

// }

function myfunc(){
    let a = document.getElementById("scroll").value;
    var top = window.scrollY;

    if (top >= 150){
        document.nav.style.background = "grey";
    }


}